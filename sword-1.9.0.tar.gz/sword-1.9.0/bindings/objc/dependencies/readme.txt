These dependencies have been moved from version control to downloads from crosswire.org/ftpmirror/pub/sword/dependencies/apple.  The included Makefile in this folder should get and expand these for you.  It should...

Unpack clucene, libcurl, and icu source packages so that you end up with folders "clucene", "curl", and "icu" within dependencies.

