//
//  SwordModuleTest.h
//  MacSword2
//
//  Created by Manfred Bergmann on 14.12.08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <XCTest/XCTest.h>

@class SwordModule;

@interface SwordModuleLongRunTest : XCTestCase {
    SwordModule *mod;
}

@end
