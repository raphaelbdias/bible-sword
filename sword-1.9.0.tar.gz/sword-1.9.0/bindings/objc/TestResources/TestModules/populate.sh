#!/bin/sh
wget "http://crosswire.org/ftpmirror/pub/sword/packages/rawzip/KJV.zip" -O KJV.zip && unzip KJV.zip && rm KJV.zip
