//
//  SWORD.h
//  SWORD
//
//  Created by scribe on 11/29/17.
//  Copyright © 2017 CrossWire Bible Society. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SWORD : NSObject

@end
